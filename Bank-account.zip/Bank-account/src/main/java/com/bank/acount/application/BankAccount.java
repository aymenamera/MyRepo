package com.bank.acount.application;

import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

import com.bank.acount.services.OperationsServices;

/*
 * This class contains the main method to lunch the application
 * and contain the method menu that will print the menu to the user 
 */
public class BankAccount {
	
	private static OperationsServices service = new OperationsServices();

	     public static void main(String[] args) throws IOException, ParseException {	
	         Menu();
	     }
	
	     /*
	      * the method menu displays the menu to the user,
	      *  and it allows him to choose the operation to perform
	      *  A to make à Deposit
	      *  B to make a Withdrawal
	      *  C to see th history
	      *  D to exit
	      */
	static void Menu() throws IOException, ParseException {
		char option = '\0';
		Scanner scanner = new Scanner(System.in);		
		System.out.println("A. Deposit");
		System.out.println("B. Withdrawal");
		System.out.println("C. History");
		System.out.println("D. Exit");
		
	do {
			
			System.out.println("*****************************");
			System.out.println("Enter an Option");
			System.out.println("*****************************");
			option=scanner.next().charAt(0);
			System.out.println("\n");

			switch (option){
			
			case 'A' :
				System.out.println("*****************************");
				System.out.println("Enter an amount to deposit");
				System.out.println("*****************************");
			    int amount = scanner.nextInt();
			    service.Deposit(amount);
			    System.out.println("\n");
			    break;
			    			    
			case 'B' :
				System.out.println("*****************************");
				System.out.println("Enter an amount to retrieve");
				System.out.println("*****************************");
			    int amount2	 = scanner.nextInt();
			    service.Withdrawal(amount2);
			    System.out.println("\n");
			    break;
			    
			case 'C' :
				System.out.println("*****************************");
				System.out.println("The history of your operations");
				System.out.println("*****************************");			   
			    service.OperationsHistory();
			    System.out.println("\n");
			    break;
			    
			case 'D' :
				System.out.println("*****************************");
			    break;    
			    
		    default:
			    	System.out.println("Invalid option ! please enter again");
			    	break;
			}
			
	}while(option != 'D');		
		System.out.println("Thank you for using our service");		
	}	
}
