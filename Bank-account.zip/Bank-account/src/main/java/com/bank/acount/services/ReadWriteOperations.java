package com.bank.acount.services;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.bank.acount.model.Operation;
import com.bank.acount.model.OperationDetails;

/*
 * the class ReadWriteOperations to save and read the operations from a text file 'OperationsHistory.txt'
 */
public class ReadWriteOperations {

	/*
	 * write operation save the operations as a line at the file OperationsHistory.txt
	 * the parameters of the object are separated by '-'
	 */
	public static  void WriteOperation(OperationDetails operation)throws IOException {
				
		String line = operation.getOperationType()+"-"+operation.getAmount()+"-"+operation.getBalance()+"-"+operation.getDate();
		 File file = new File("OperationsHistory.txt");
		  if(!file.exists())
			    file.createNewFile();
 	    FileWriter fw = new FileWriter(file, true);
 	    BufferedWriter bw = new BufferedWriter(fw);      
 	    if( file.length() != 0) {
 	    bw.newLine();
 	    }
 	    bw.write(line);
 	    bw.close();		
	}
	
	public static OperationDetails  ReadLastOperation()throws IOException, ParseException {
				
		/*
		 * ReadLastOperation read the last operation as a line from the file OperationsHistory.txt
		 * and convert the String line to an object to return it
		 */
		OperationDetails operation = new OperationDetails();
		 File file = new File("OperationsHistory.txt");
		  if(!file.exists())
			  return null;
		  BufferedReader input = new BufferedReader(new FileReader(file));
		    String last = null, line;
		    while ((line = input.readLine()) != null) {
		        last = line;
		    }		
		    if (last == null) {
		    	return null;
		    }		    
		    String[] LineToObj = last.split("-");
		    operation.setOperationType(Operation.valueOf( LineToObj[0]));
		    operation.setAmount(Integer.parseInt(LineToObj[1]));
		    operation.setBalance(Integer.parseInt(LineToObj[2]));
		    operation.setDate(LineToObj[3]);
		    input.close();
		return operation;    
	}

	/*
	 * ReadAllOperations read all the operations  from the file OperationsHistory.txt
	 * and return a list of operations
	 */
public static List<OperationDetails>  ReadAllOperations()throws IOException, ParseException {
		
	      List<OperationDetails> operationsList = new ArrayList<OperationDetails>();	
		  File file = new File("OperationsHistory.txt");
		  if(!file.exists())
			  return null;
		  BufferedReader input = new BufferedReader(new FileReader(file));
		  String line = null;
		    if (file.length() == 0) {
		    	return null;
		    }		    
		    while ((line = input.readLine()) != null) {
		    	OperationDetails operation = new OperationDetails();
		    	 String[] LineToObj = line.split("-");
				    operation.setOperationType(Operation.valueOf( LineToObj[0]));
				    operation.setAmount(Integer.parseInt(LineToObj[1]));
				    operation.setBalance(Integer.parseInt(LineToObj[2]));
				    operation.setDate(LineToObj[3]);
				    operationsList.add(operation);
		    }		   
		    input.close();		    	  
		return operationsList;    
	}	
}