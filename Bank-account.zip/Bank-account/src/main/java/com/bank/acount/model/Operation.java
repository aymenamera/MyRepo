package com.bank.acount.model;

public enum Operation {
	deposit,
	withdrawal,
    
}