package com.bank.acount.model;

public class OperationDetails {

	/*
	 * This Class contains the details of the Operations
	 * Date , the amount of the operation, the balance after the operation 
	 * and the type of the operation (deposit or withdrawal)
	 */
	
	private String date;
	private int  amount;
	private int  balance;
	private Operation OperationType;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Operation getOperationType() {
		return OperationType;
	}
	public void setOperationType(Operation operationType) {
		OperationType = operationType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((OperationType == null) ? 0 : OperationType.hashCode());
		result = prime * result + amount;
		result = prime * result + balance;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OperationDetails other = (OperationDetails) obj;
		if (OperationType != other.OperationType)
			return false;
		if (amount != other.amount)
			return false;
		if (balance != other.balance)
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OperationDetails [date=" + date + ", amount=" + amount + ", balance=" + balance + ", OperationType="
				+ OperationType + "]";
	}
	
	
	
	

}
