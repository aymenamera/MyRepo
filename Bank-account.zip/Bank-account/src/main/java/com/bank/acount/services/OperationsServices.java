package com.bank.acount.services;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.bank.acount.model.Operation;
import com.bank.acount.model.OperationDetails;

public class OperationsServices {	
	/*
	 * this class contains the services that can be requested by the client
	 * 
	 */	
private static OperationDetails op = new OperationDetails();
private static Date today = new Date();
static DateFormat formatter = new SimpleDateFormat("dd/MMM/yy");
	  
// this method allows the user to make a deposit in his account
public  void Deposit (int amount) throws IOException, ParseException {
	
	/*this object contains the last operations to update the balance with the new deposit
	 * if the user will make his first deposit, the lastBalance will be 0.
	 */
	 OperationDetails lastOp = ReadWriteOperations.ReadLastOperation();
	 int lastBalance ;
	 if (lastOp == null) {
		 lastBalance = 0;
	 }else {
		 lastBalance=lastOp.getBalance();
	 }	 
	if (amount !=0) {	
		op.setBalance(lastBalance+amount);
	}
	op.setAmount(amount);		
	op.setDate(formatter.format(today));
	op.setOperationType(Operation.deposit);
	
	//WriteOperation to save the operation done by the User
	ReadWriteOperations.WriteOperation(op);	
}

//this method allows the user to make a Withdrawal from his account
public void Withdrawal (int amount) throws IOException, ParseException {
	/*this object contains the last operations to update the balance with the new deposit
	 * if the user will make his first deposit, the lastBalance will be 0.
	 */
	 OperationDetails lastOp = ReadWriteOperations.ReadLastOperation();
		int lastBalance,newBalance=0 ;
		 if (lastOp == null) {
			 lastBalance = 0;
		 }else {
			 lastBalance=lastOp.getBalance();
		 }		 
		if (amount !=0) {			
			newBalance=lastBalance-amount;
		}	
		// if the new Balance <0  a message will be posted to the user
		if(newBalance<0) {
			System.out.println("Your balance does not allow you to perform this operation");
		}else {		
	op.setBalance(lastBalance-amount);
	op.setAmount(amount);	
	op.setDate(formatter.format(today));
	op.setOperationType(Operation.withdrawal);
	//WriteOperation to save the operation done by the User
	ReadWriteOperations.WriteOperation(op);}
}

//this method allows the user to see the history of his operations
public void OperationsHistory() throws IOException, ParseException {
	
	// allOp contains all the operations
	List<OperationDetails> allOper = ReadWriteOperations.ReadAllOperations();	
	// the lis of the operations will be posted as a table (Type of the operation, the amount, the balance and the date)
	    if(allOper != null) {
	  	  System.out.println(String.format("%-10s%-10s%-10s%-10s", "Operation", "  Amount", "  Balance", "  Date"));
		    System.out.println();
	    for (OperationDetails Op : allOper)
	        System.out.println(String.format("%-10s%-10d%-10d%-10s", Op.getOperationType(), Op.getAmount(), Op.getBalance(),Op.getDate()));
	}else {
		 System.out.println("You didn't make any operation");
	}
}}
